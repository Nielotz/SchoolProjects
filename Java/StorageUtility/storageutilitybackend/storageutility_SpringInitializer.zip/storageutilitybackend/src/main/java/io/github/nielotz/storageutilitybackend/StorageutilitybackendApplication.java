package io.github.nielotz.storageutilitybackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StorageutilitybackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(StorageutilitybackendApplication.class, args);
	}

}
