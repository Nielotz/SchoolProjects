package io.github.nielotz.storageutilitybackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StorageutilitybackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
